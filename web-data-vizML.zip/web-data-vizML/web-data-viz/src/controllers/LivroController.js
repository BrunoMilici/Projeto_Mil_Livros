var livroModel = require("../models/livroModel");


function registrar(req, res) {
    var tituloLivro = req.body.tituloLivroServer;
    var generoLivro = req.body.generoLivroServer;

    if (tituloLivro == undefined) {
        res.status(400).send("Seu tituloLivro está undefined!");
    } else if (generoLivro == undefined) {
        res.status(400).send("Seu generoLivro está undefined!");
    } else {

        livroModel.registrar(tituloLivro, generoLivro)
            .then(
                function (resultado) {
                    res.json(resultado);
                }
            ).catch(
                function (erro) {
                    console.log(erro);
                    console.log(
                        "\nHouve um erro no regisro do livro! Erro: ",
                        erro.sqlMessage
                    );
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}

function autenticar(req, res) {
    var tituloLivro = req.body.tituloLivroServer;

    if (tituloLivro == undefined) {
        res.status(400).send("Seu email está undefined!");
    } else {

        livroModel.autenticar(tituloLivro)
            .then(
                function (resultadoAutenticar) {
                    console.log(`\nResultados encontrados: ${resultadoAutenticar.length}`);
                    console.log(`Resultados: ${JSON.stringify(resultadoAutenticar)}`); // transforma JSON em String

                        res.json(resultadoAutenticar);

                }
            ).catch(
                function (erro) {
                    console.log(erro);
                    console.log("\nHouve um erro ao verificar os livros cadastrados! Erro: ", erro.sqlMessage);
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}


function publicar(req, res) {
    var fkLivro = req.body.fkLivroServer;
    var fkUsuarioAnalise = req.body.fkUsuarioAnaliseServer;
    var nota = req.params.notaServer;
    var resenha = req.params.resenhaServer;

    if (fkLivro == undefined) {
        res.status(400).send("A fkLivro está indefinida!");
    } else if (fkUsuarioAnalise == undefined) {
        res.status(400).send("A fkUsuarioAnalise está indefinida!");
    } else if (nota == undefined) {
        res.status(403).send("A nota do livro está indefinido!");
    }else if (resenha == undefined) {
        res.status(403).send("A resenha do formulário está indefinido!");
    }  else {
        livroModel.publicar(fkLivro, fkUsuarioAnalise, nota, resenha)
            .then(
                function (resultado) {
                    res.json(resultado);
                }
            )
            .catch(
                function (erro) {
                    console.log(erro);
                    console.log("Houve um erro ao realizar o post: ", erro.sqlMessage);
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}


module.exports = {
    registrar,
    autenticar,
    publicar
}