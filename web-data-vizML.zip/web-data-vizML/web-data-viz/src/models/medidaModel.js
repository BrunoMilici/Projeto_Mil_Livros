var database = require("../database/config");

function buscarUltimasMedidas() {

    var instrucaoSql = `SELECT g.generoLiterario, COUNT(p.idPerfil) AS totalUsuarios
    FROM Perfil p
    JOIN generosLiterarios g ON p.fkGeneroFavorito = g.idGenero
    GROUP BY g.generoLiterario;`;

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);
}

module.exports = {
    buscarUltimasMedidas
}
